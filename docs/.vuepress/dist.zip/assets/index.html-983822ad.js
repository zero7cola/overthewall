import{_ as e,o as c,c as t}from"./app-e3f8d77b.js";const n={};function _(o,r){return c(),t("div")}const a=e(n,[["render",_],["__file","index.html.vue"]]);export{a as default};
